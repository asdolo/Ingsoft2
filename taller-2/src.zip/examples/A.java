public class A 
{
	public int ejercicio1 (int m, int n) {
		int x = 0;
		int j = m / (x * n);
		return j;
	}
}
