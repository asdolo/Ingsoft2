public class C 
{
	public int ejercicio3 (int m, int n) {
		int x = 0;
		if (m != 0) {
			x = m;
		} else {
			x = 1;
		}
		int j = n / x;
		return j;
	}
}
