public class B 
{
	public int ejercicio2 (int m, int n) {
		int x = n - n;
		int i = x + m;
		int j = m / x;
		return j;
	}
}
