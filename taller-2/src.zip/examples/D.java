public class D
{
	public int ejercicio4 (int m, int n) {
		int x = 0;
		int j = m / n;
		return j;
	}
}
